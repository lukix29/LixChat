﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace LX29_Twitch.Api
{
    public enum SubType
    {
        Prime = 0000,
        Tier1 = 1000,
        Tier2 = 2000,
        Tier3 = 3000
    }

    public enum ApiInfo
    {
        _id,
        follow,
        average_fps,
        background,
        banner,
        broadcaster_language,
        created_at,
        delay,
        display_name,
        followers,
        game,
        is_playlist,
        language,
        large,
        logo,
        mature,
        name,
        partner,
        profile_banner,
        profile_banner_background_color,
        status,
        stream_created_at,
        follow_created_at,
        stream_id,
        updated_at,
        url,
        video_banner,
        video_height,
        viewers,
        views,
        sub_plan,
        sub_plan_name
    }

    public enum FFZEmoteInfo
    {
        css,
        height,
        hidden,
        id,
        margins,
        name,
        owner,
        urls,
        width,
    }

    public enum PanelInfo
    {
        _id,
        display_order,
        kind,
        html_description,
        user_id,
        link,
        image,
        title,
        description
    }

    public class ApiResult
    {
        public static readonly ApiResult Empty = new ApiResult(null);

        private static readonly ApiInfo[] apiInfoSort = new ApiInfo[]{
            ApiInfo.display_name ,ApiInfo.url, ApiInfo.game ,
            ApiInfo.status , ApiInfo.viewers ,ApiInfo.follow_created_at, ApiInfo.followers,
            ApiInfo.video_height , ApiInfo.average_fps, ApiInfo.views};

        private Dictionary<ApiInfo, object> values;

        public ApiResult(ApiResult result, ApiResult result1)
        {
            values = result.values;

            foreach (var t in result1.values)
            {
                if (!values.ContainsKey(t.Key))
                {
                    values.Add(t.Key, t.Value);
                }
            }
        }

        public ApiResult(Dictionary<ApiInfo, string> ChannelValues, Dictionary<ApiInfo, string> StreamValues = null)
        {
            //EmoteSets = emoteSets;
            this.values = new Dictionary<ApiInfo, object>();

            if (ChannelValues != null && ChannelValues.Count > 0)
            {
                foreach (var channel in ChannelValues)
                {
                    var o = ConvertValue(channel.Value, channel.Key);
                    values.Add(channel.Key, o);
                }
            }

            if (StreamValues != null && StreamValues.Count > 0)
            {
                foreach (var stream in StreamValues)
                {
                    if (stream.Key == ApiInfo._id)
                    {
                        if (!values.ContainsKey(ApiInfo.stream_id))
                        {
                            var o = ConvertValue(stream.Value, ApiInfo.stream_id);
                            values.Add(ApiInfo.stream_id, o);
                        }
                    }
                    else if (stream.Key == ApiInfo.created_at)
                    {
                        if (!values.ContainsKey(ApiInfo.stream_created_at))
                        {
                            var o = ConvertValue(stream.Value, ApiInfo.stream_created_at);
                            values.Add(ApiInfo.stream_created_at, o);
                        }
                    }
                    else if (stream.Key == ApiInfo.large)
                    {
                        if (!values.ContainsKey(ApiInfo.large))
                        {
                            var o = ConvertValue(stream.Value, ApiInfo.large);
                            values.Add(ApiInfo.large, o);
                        }
                    }
                    else if (!values.ContainsKey(stream.Key))
                    {
                        var o = ConvertValue(stream.Value, stream.Key);
                        values.Add(stream.Key, o);
                    }
                }
            }
        }

        public bool Followed
        {
            get { return GetValue<bool>(ApiInfo.follow); }
        }

        public string ID
        {
            get { return GetValue<string>(ApiInfo._id); }
        }

        public string Infos
        {
            get
            {
                StringBuilder sb = new StringBuilder();

                var names = Enum.GetNames(typeof(ApiInfo)).ToList();
                foreach (var ai in apiInfoSort)
                {
                    string name = Enum.GetName(typeof(ApiInfo), ai);
                    if (values.ContainsKey(ai))
                    {
                        string s = values[ai].ToString();
                        if (s.Length > 0)
                        {
                            sb.Append(name.Replace("_", " ").ToTitleCase() + ": ");

                            sb.AppendLine(s);
                            sb.AppendLine();
                        }
                    }
                    names.Remove(name);
                }
                foreach (var Key in names)
                {
                    ApiInfo info = (ApiInfo)Enum.Parse(typeof(ApiInfo), Key);
                    if (values.ContainsKey(info))
                    {
                        string s = values[info].ToString();
                        if (s.Length > 0)
                        {
                            sb.Append(Key.Replace("_", " ").ToTitleCase() + ": ");

                            sb.AppendLine(s);
                            sb.AppendLine();
                        }
                    }
                }
                return sb.ToString();
            }
        }

        public bool IsEmpty
        {
            get { return values.Count == 0; }
        }

        public bool IsOnline
        {
            get { return values.ContainsKey(ApiInfo.stream_id); }
        }

        public string Name
        {
            get { return GetValue<string>(ApiInfo.name); }
        }

        public TimeSpan OnlineTime
        {
            get
            {
                DateTime dt = (IsOnline) ? GetValue<DateTime>(ApiInfo.stream_created_at) : GetValue<DateTime>(ApiInfo.created_at);
                return DateTime.Now.Subtract(dt);
            }
        }

        public string OnlineTimeString
        {
            get
            {
                return ((IsOnline) ? "Online: " : "Created: ") +
                    OnlineTime.ToString((OnlineTime.TotalDays >= 1.0) ? @"%d'd 'hh':'mm':'ss" : @"hh\:mm\:ss");
            }
        }

        public Dictionary<ApiInfo, object> Values
        {
            get { return values; }
        }

        public T GetValue<T>(ApiInfo type)
        {
            if (values.ContainsKey(type))
            {
                return (T)values[type];
            }
            return default(T);
        }

        public void ResetStreamStatus()
        {
            if (values.ContainsKey(ApiInfo.stream_id))
                values.Remove(ApiInfo.stream_id);
            if (values.ContainsKey(ApiInfo.stream_created_at))
                values.Remove(ApiInfo.stream_created_at);
            if (values.ContainsKey(ApiInfo.large))
                values.Remove(ApiInfo.large);
        }

        private object ConvertValue(string si, ApiInfo type)
        {
            if (si.Length == 0) return si;
            bool b = false;
            if (type == ApiInfo.created_at || type == ApiInfo.updated_at
                || type == ApiInfo.stream_created_at || type == ApiInfo.follow_created_at)
            {
                string s = si.Replace("T", " ").Replace("Z", "");
                return DateTime.Parse(s).ToLocalTime();
            }
            else if (type == ApiInfo.name)
            {
                return si;
            }
            else if (type == ApiInfo.language)
            {
                string s = si;
                if (si == "null")
                {
                    s = "English";
                }
                else
                {
                    CultureInfo ci = CultureInfo.GetCultureInfo(s, s);
                    if (CultureInfo.CurrentCulture.EnglishName.Contains(ci.EnglishName))
                    {
                        s = ci.NativeName;
                    }
                    else
                    {
                        s = ci.EnglishName;
                    }
                }
                return s;
            }
            else if (type == ApiInfo.followers || type == ApiInfo.viewers ||
                type == ApiInfo.views || type == ApiInfo.video_height || type == ApiInfo.average_fps)
            {
                string s = (si.Contains('.')) ? si.Remove(si.IndexOf('.')) : si;
                int i = 0;
                if (int.TryParse(s, out i))
                {
                    s = i.ToString("N0");
                    if (type == ApiInfo.video_height)
                    {
                        s += "p";
                    }
                    else if (type == ApiInfo.average_fps)
                    {
                        s += "fps";
                    }
                    return s;
                }
            }
            else if (type == ApiInfo.sub_plan)
            {
                SubType subtype = SubType.Prime;
                if (Enum.TryParse<SubType>(si, out subtype))
                {
                }
                else
                {
                }
                return subtype;
            }
            else if (bool.TryParse(si, out b))
            {
                return b;
            }
            return si;
        }
    }

    public class EmoteInfo
    {
        public EmoteInfo(int id, string name, int set_id)
        {
            Emote_ID = id;
            Name = name;
            Set_ID = set_id;
        }

        public int Emote_ID
        {
            get;
            private set;
        }

        public string Name
        {
            get;
            private set;
        }

        public int Set_ID
        {
            get;
            private set;
        }

        public override string ToString()
        {
            return Set_ID + ": " + Name + " (Emote_ID: " + Emote_ID + ")";
        }
    }

    public class PanelResult
    {
        private System.Drawing.Image image = null;
        private Dictionary<PanelInfo, object> values;

        public PanelResult(Dictionary<PanelInfo, string> infos)
        {
            values = new Dictionary<PanelInfo, object>();
            foreach (var s in infos)
            {
                object o = s.Value;
                int i = 0;
                bool b = false;
                if (int.TryParse(s.Value, out i))
                {
                    o = i;
                }
                else if (bool.TryParse(s.Value, out b))
                {
                    o = b;
                }
                else
                {
                    o = s.Value.Trim(" ", "{", "}", "null");
                }
                if (!values.ContainsKey(s.Key))
                {
                    values.Add(s.Key, o);
                }
            }
        }

        public string Decription
        {
            get { return GetValue<string>(PanelInfo.description); }
        }

        public string HTML
        {
            get { return GetValue<string>(PanelInfo.html_description); }
        }

        public System.Drawing.Image Image
        {
            get
            {
                if (image == null)
                {
                    try
                    {
                        string url = GetValue<string>(PanelInfo.image);
                        if (!string.IsNullOrEmpty(url))
                        {
                            image = new System.Drawing.Bitmap(1, 1);
                            WebClient wc = new WebClient();
                            wc.Proxy = null;
                            var t = wc.DownloadData(url);
                            //var wait = t.GetAwaiter();
                            //wait.OnCompleted(new Action(delegate()
                            //{
                            using (var ms = new MemoryStream(t))
                            {
                                image = System.Drawing.Bitmap.FromStream(ms);
                            }
                            wc.Dispose();
                            //}));
                        }
                    }
                    catch { image = null; }
                    return image;
                }
                else return image;
            }
        }

        public int Index
        {
            get { return GetValue<int>(PanelInfo.display_order); }
        }

        public string Link
        {
            get { return GetValue<string>(PanelInfo.link); }
        }

        public string Title
        {
            get { return GetValue<string>(PanelInfo.title); }
        }

        public int User_ID
        {
            get { return GetValue<int>(PanelInfo.user_id); }
        }

        public T GetValue<T>(PanelInfo type)
        {
            if (values.ContainsKey(type))
            {
                return (T)values[type];
            }
            return default(T);
        }
    }

    public class SubResult
    {
        public static readonly SubResult Empty = new SubResult(ApiResult.Empty);

        public static SubResult Parse(object res)
        {
            if (res is WebException)
            {
                //Has sub Programm but User is no Sub (404 == User has no sub at Channel)
                if ((((WebException)res).Response as HttpWebResponse).StatusCode == HttpStatusCode.NotFound)
                {
                    return new SubResult();
                }
            }
            else
            {
                //Parse Sub Info
                var apires = JSON_Parser.JSON.Parse(res.ToString());
                if (apires.Count > 0)
                {
                    return new SubResult(apires[0]);
                }
            }
            //No Sub Programm
            return SubResult.Empty;
        }

        public SubResult()
        {
            Base = ApiResult.Empty;
            IsEmpty = false;
            IsSub = false;
        }

        public SubResult(ApiResult result)
        {
            IsEmpty = result.IsEmpty;

            IsSub = !result.IsEmpty;

            Base = result;
        }

        //Sub Type (Prime, Tier1, Tier2, Tier3)
        public SubType Type
        {
            get { return Base.GetValue<SubType>(ApiInfo.sub_plan); }
        }

        //Sub Plan Name
        public string PlanName
        {
            get { return Base.GetValue<string>(ApiInfo.sub_plan_name); }
        }

        //Last Sub Date
        public DateTime Date
        {
            get
            {
                if (Base.Values.ContainsKey(ApiInfo.follow_created_at))
                {
                    return Base.GetValue<DateTime>(ApiInfo.follow_created_at);
                }
                return DateTime.MinValue;
            }
        }

        //Latest Date for resubscription
        public DateTime FutureResubDate
        {
            get
            {
                if (!Date.Equals(DateTime.MinValue))
                {
                    return SubEndDate.AddDays(30);
                }
                else
                {
                    return DateTime.MinValue;
                }
            }
        }

        //Sub end Date, e.g. losing badge & emotes
        public DateTime SubEndDate
        {
            get
            {
                if (!Date.Equals(DateTime.MinValue))
                {
                    //frag mi ned, auf twitch steht prime läuft nach 30 tagen aus, aber alle
                    //anderen die ich extra nachgezählt habe nach 32,
                    //also sicherheitshalber mal so machen XD
                    return (Type == SubType.Prime) ? Date.AddDays(30) : Date.AddDays(31);
                }
                else
                {
                    return DateTime.MinValue;
                }
            }
        }

        public ApiResult Base
        {
            get;
            private set;
        }

        //If no sub-programm, True
        public bool IsEmpty
        {
            get;
            private set;
        }

        //If user can sub & is sub, True
        public bool IsSub
        {
            get;
            private set;
        }
    }
}