﻿using LX29_Twitch.JSON_Parser;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace LX29_Twitch.Api
{
    public static class TwitchApi
    {
        public const string CLIENT_ID = "n0soi61qkugd4mjlq618r243k686o69";

        private static Random rd = new Random();

        public static string AuthApiUrl
        {
            get
            {
                return "https://api.twitch.tv/kraken/oauth2/authorize?response_type=token&client_id="
                    + CLIENT_ID + "&redirect_uri=https://twitchapps.com/tokengen/&force_verify=true&" +
                    "scope=chat_login+user_subscriptions+user_read+user_follows_edit";
            }
        }

        public static bool FollowChannel(string userID, ApiResult channelID, string token)
        {
            try
            {
                bool wasFollowed = channelID.Followed;
                string param = (wasFollowed) ? "DELETE" : "PUT";
                string raw = uploadString(
                    "https://api.twitch.tv/kraken/users/" + userID + "/follows/channels/" + channelID.ID, param, token);
                if (!wasFollowed)
                {
                    if (raw.Length > 0)
                    {
                        channelID.Values[ApiInfo.follow] = true;
                    }
                }
                else
                {
                    channelID.Values[ApiInfo.follow] = false;
                }
                return true;
            }
            catch// (Exception x)
            {
            }
            return false;
        }

        public static IEnumerable<LX29_ChatClient.ChatUser> GetChatUsers(string ChannelName)
        {
            string values = downloadString("https://tmi.twitch.tv/group/user/" + ChannelName + "/chatters").ToString().ReplaceAll("", " ", "\n", "\"");

            var users = values.GetBetween("moderators:[", "]").Split(",")
                .Select(t => new { UType = LX29_ChatClient.UserType.moderator, Name = t }).ToList();

            users.AddRange(values.GetBetween("staff:[", "]").Split(",")
                .Select(t => new { UType = LX29_ChatClient.UserType.staff, Name = t }));

            users.AddRange(values.GetBetween("admins:[", "]").Split(",")
                .Select(t => new { UType = LX29_ChatClient.UserType.admin, Name = t }));

            users.AddRange(values.GetBetween("global_mods:[", "]").Split(",")
                .Select(t => new { UType = LX29_ChatClient.UserType.global_mod, Name = t }));

            users.AddRange(values.GetBetween("viewers:[", "]").Split(",")
                .Select(t => new { UType = LX29_ChatClient.UserType.NORMAL, Name = t }));

            return users.Select(t => new LX29_ChatClient.ChatUser(t.Name, ChannelName, t.UType));
        }

        public static List<ApiResult> GetFollowedStreams(string User_ID, string token)
        {
            try
            {
                List<ApiResult> list = getResults("https://api.twitch.tv/kraken/users/" + User_ID + "/follows/channels", token);
                string sb = getChannelList(list);
                var str = getResults("https://api.twitch.tv/kraken/streams?channel=" + sb, token);
                return Combine(list, str);
            }
            catch { }
            return new List<ApiResult>();
        }

        public static List<ApiResult> GetFriends(string id)
        {
            string url = "https://api.twitch.tv/kraken/users/" + id + "/friends";
            string dl = downloadString(url);
            return null;
        }

        public static ApiResult GetStreamOrChannel(string ID, string userID)
        {
            //streams arent loaded when loaded not from follow list (doesnt fetch stream id in JSON PArser)
            Dictionary<ApiInfo, string> arr = new Dictionary<ApiInfo, string>();
            string id = "";
            string url = "";
            //if (fetchfollowed)
            //{
            //    url = "https://api.twitch.tv/kraken/users/" + userID + "/follows/channels/" + ID;//
            //    id = downloadString(url);
            //    arr = JSON.SplitInner<ApiInfo>(id);
            //}
            //if (arr.Count > 1)
            //{
            //    return new ApiResult(arr);
            //}
            //else
            //{
            url = "https://api.twitch.tv/kraken/streams/" + ID;
            id = downloadString(url);
            var res = JSON.Parse(id);
            if (res.Count > 0)
            {
                return res[0];
            }
            url = "https://api.twitch.tv/kraken/channels/" + ID;
            id = downloadString(url);
            res = JSON.Parse(id);
            if (res.Count > 0)
            {
                return res[0];
            }
            //}
            return ApiResult.Empty;
        }

        public static List<PanelResult> GetStreamPanels(string name)
        {
            string json = downloadString("https://api.twitch.tv/api/channels/" + name + "/panels", null, 3);
            json = json.ReplaceAll("", "[", "]");
            var sa = json.Split("},{");
            List<PanelResult> list = new List<PanelResult>();
            foreach (var s in sa)
            {
                var dict = JSON.SplitPanelInner<PanelInfo>(s);
                list.Add(new PanelResult(dict));
            }
            return list.OrderByDescending(t => t.Index).ToList();
        }

        public static List<ApiResult> GetStreams(IEnumerable<ApiResult> res)
        {
            string sb = getChannelList(res);
            string s = downloadString("https://api.twitch.tv/kraken/streams?channel=" + sb + "&limit=100");
            var str = JSON.Parse(s);
            return str;
            //return Combine(res, str);
        }

        public static SubResult GetSubscription(string user_ID, string channel_ID, string token)
        {
            var res = downloadString(
                "https://api.twitch.tv/kraken/users/" + user_ID + "/subscriptions/" + channel_ID, false, token);
            return SubResult.Parse(res);
        }

        public static List<EmoteInfo> GetUserEmotes(string id, string token)
        {
            string s = downloadString("https://api.twitch.tv/kraken/users/" + id + "/emotes", token);
            s = s.Replace("\"", "");
            s = s.RemoveUntil("{", 1);
            var sets = s.Split("],");
            List<EmoteInfo> list = new List<EmoteInfo>();
            foreach (var set in sets)
            {
                int setId = int.Parse(set.GetBetween("", ":"));
                var emotes = set.RemoveUntil("{").Split("},{");
                foreach (var em in emotes)
                {
                    int emid = int.Parse(em.GetBetween("id:", ","));
                    string name = em.GetBetween("code:");
                    list.Add(new EmoteInfo(emid, name, setId));
                }
            }
            return list;
        }

        public static List<ApiResult> GetUserID(params string[] name)
        {
            string url = "https://api.twitch.tv/kraken/users?login=" + getChannelList(name);
            string id = downloadString(url);
            var sa = id.Split("},{");
            List<ApiResult> list = new List<ApiResult>();
            foreach (var s in sa)
            {
                var res = JSON.Parse(s);
                list.AddRange(res);
            }
            return list;
            //return id.Replace("\"", "").GetBetween("_id:", ",");
        }

        public static ApiResult GetUserID(string name)
        {
            string url = "https://api.twitch.tv/kraken/users?login=" + name;
            string id = downloadString(url);
            var res = JSON.Parse(id);
            if (res.Count > 0)
            {
                return res[0];
            }
            return ApiResult.Empty;
            //return id.Replace("\"", "").GetBetween("_id:", ",");
        }

        public static ApiResult GetUserIDFromToken(string Token)
        {
            WebClient wc = new WebClient();
            wc.Encoding = Encoding.UTF8;
            wc.Proxy = null;
            string result = wc.DownloadString("https://api.twitch.tv/kraken?oauth_token=" + Token);
            result = result.GetBetween("https://api.twitch.tv/kraken/users/", "\"");

            return GetUserID(result);
        }

        private static List<ApiResult> Combine(IEnumerable<ApiResult> channels, IEnumerable<ApiResult> streams)
        {
            List<ApiResult> list = new List<ApiResult>();
            foreach (var channel in channels)
            {
                //channel.Values.Add(ApiInfo.follow, true);
                var stream = streams.FirstOrDefault(t => t.ID.Equals(channel.ID));
                if (stream != null)
                {
                    list.Add(new ApiResult(channel, stream));
                }
                else
                {
                    list.Add(channel);
                }
            }

            return list;//.OrderByDescending(t => t.IsOnline)).ToList();
        }

        private static string downloadString(string url, string tokken = null, int api_version = 5)
        {
            return downloadString(url, true, tokken, api_version).ToString();
        }

        private static object downloadString(string url, bool handleError, string tokken = null, int api_version = 5)
        {
            try
            {
                using (WebClient webclient = new WebClient())
                {
                    webclient.Proxy = null;
                    webclient.Encoding = Encoding.UTF8;
                    if (url.Contains("api.twitch.tv"))
                    {
                        webclient.Headers.Add("Accept: application/vnd.twitchtv.v" + api_version + "+json");
                        webclient.Headers.Add("Client-ID: " + CLIENT_ID);
                        if (!string.IsNullOrEmpty(tokken))
                        {
                            webclient.Headers.Add("Authorization: OAuth " + tokken);
                        }
                    }
                    return webclient.DownloadString(url);
                }
            }
            catch (WebException x)
            {
                var info = TwitchApiErrors.GetError(x);
                if (handleError)
                {
                    switch (x.Handle(info))
                    {
                        case System.Windows.Forms.MessageBoxResult.Retry:
                            return downloadString(url, tokken, api_version);
                    }
                }
                else
                {
                    return x;
                }
            }
            return string.Empty;
        }

        private static string getChannelList(IEnumerable<string> results)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var a in results)
            {
                sb.Append(a + ",");
            }
            sb.Remove(sb.Length - 1, 1);
            return sb.ToString();
        }

        private static string getChannelList(IEnumerable<ApiResult> results)
        {
            var ids = results.Select(t => t.ID);
            return getChannelList(ids);
        }

        private static List<ApiResult> getResults(string Url, string token)
        {
            int total = 100;
            int limit = 100;
            int offset = 0;
            string s = downloadString(Url + ((Url.Contains("?") ? "&" : "?")) + "limit=" + limit + "&sortby=last_broadcast", token);
            string tt = s.GetBetween("\"_total\":", "}");
            int.TryParse(tt, out total);

            List<ApiResult> list = new List<ApiResult>();
            list.AddRange(JSON.Parse(s));
            if (list.Count >= limit)
            {
                offset += list.Count;
                while (true)
                {
                    s = downloadString(Url + ((Url.Contains("?") ? "&" : "?")) + "limit=" + limit + "&sortby=last_broadcast&offset=" + offset, token);
                    var temp = JSON.Parse(s);
                    if (temp.Count > 0)
                    {
                        offset += temp.Count;
                        list.AddRange(temp);
                    }
                    else
                    {
                        break;
                    }
                }
            }
            return list;
        }

        private static string uploadString(string url, string param, string tokken = null, int api_version = 5)
        {
            try
            {
                using (WebClient webclient = new WebClient())
                {
                    webclient.Proxy = null;
                    webclient.Encoding = Encoding.UTF8;
                    if (url.Contains("api.twitch.tv"))
                    {
                        webclient.Headers.Add("Accept: application/vnd.twitchtv.v" + api_version + "+json");
                        webclient.Headers.Add("Client-ID: " + CLIENT_ID);
                        if (!string.IsNullOrEmpty(tokken))
                        {
                            webclient.Headers.Add("Authorization: OAuth " + tokken);
                        }
                    }
                    return webclient.UploadString(url, param, "");
                    //  return webclient.DownloadString(url);
                }
            }
            catch (WebException x)
            {
                var info = TwitchApiErrors.GetError(x);
                switch (x.Handle(info))
                {
                    case System.Windows.Forms.MessageBoxResult.Retry:
                        return uploadString(url, param, tokken, api_version);
                }
            }
            return null;
        }
    }

    public class TwitchApiErrors
    {
        private static Dictionary<int, string> dict = new Dictionary<int, string>()
        {
            { -10, "Generic Error."},
            { 400, "Request Not Valid. Something is wrong with the request."},
            { 401, "Unauthorized. The OAuth token does not have the correct scope or does not have the required permission on behalf of the specified user."},
            { 403, "Forbidden. This usually indicates that authentication was provided, but the authenticated user is not permitted to perform the requested operation.\r\nFor example, a user who is not a partner might have tried to start a commercial."},
            { 404, "Not Found. For example, the channel, user, or relationship could not be found."},
            { 422, "Unprocessable Entity. For example, for a user subscription endpoint, the specified channel does not have a subscription program."},
            { 429, "Too Many Requests."},
            { 500, "Internal Server Error."},
            { 503, "Service Unavailable. For example, the status of a game or ingest server cannot be retrieved."}
        };

        public static string GetError(WebException x)
        {
            if (x.Response != null)
            {
                var res = x.Response as HttpWebResponse;
                int code = (int)res.StatusCode;
                if (dict.ContainsKey(code))
                {
                    return dict[code];
                }
            }
            return dict[-10];
        }
    }
}