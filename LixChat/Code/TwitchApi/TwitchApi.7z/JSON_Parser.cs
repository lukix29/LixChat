﻿using LX29_Twitch.Api;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LX29_Twitch.JSON_Parser
{
    public static class JSON
    {
        public static List<ApiResult> Parse(string input)
        {
            input = input.ReplaceAll("", "[", "]");
            string chSpl = "\"channel\":";
            string strSpl = "\"stream";
            string prvSpl = "\"preview\":";
            List<ApiResult> list = new List<ApiResult>();
            if (input.Contains(chSpl))
            {
                int end = 1;
                while (end >= 0)
                {
                    int start = input.IndexOf(chSpl, end);
                    var stream = new Dictionary<ApiInfo, string>();
                    if (input.Contains(strSpl))
                    {
                        int fi = input.IndexOf('{', end);
                        if (fi >= 0)
                        {
                            string strm = input.Substring(fi, start - fi);
                            stream = SplitInner<ApiInfo>(strm, input);
                        }
                    }
                    if (input.Contains(prvSpl))
                    {
                        int fi = input.IndexOf(prvSpl, end);
                        if (fi >= 0)
                        {
                            int nd = input.IndexOf("},", fi);
                            string strm = input.Substring(fi, nd - fi);
                            var prevs = SplitInner<ApiInfo>(strm, input);
                            if (prevs.ContainsKey(ApiInfo.large))
                            {
                                if (!stream.ContainsKey(ApiInfo.large))
                                {
                                    stream.Add(ApiInfo.large, prevs[ApiInfo.large]);
                                }
                            }
                        }
                    }
                    if (start < 0) break;
                    end = input.IndexOf("}}", start - chSpl.Length);
                    if (end < 0) break;
                    string sub = input.Substring(start, end - start);
                    string fca = "\"follow_" + input.GetBefore(sub, "created_at");
                    sub = fca + sub;
                    if (!string.IsNullOrEmpty(sub))
                    {
                        var val = SplitInner<ApiInfo>(sub, input);
                        if (val.Count > 0)
                        {
                            var v = new ApiResult(val, stream);
                            list.Add(v);
                        }
                    }
                }
            }
            else
            {
                var val = SplitInner<ApiInfo>(input);
                if (val.Count > 0)
                {
                    var v = new ApiResult(val);
                    list.Add(v);
                }
            }
            return list;
        }

        //public static List<EmoteResult> ParseEmotes(string input)
        //{
        //    //string[] sa = input.Split("},{");
        //    List<EmoteResult> list = new List<EmoteResult>();
        //    //foreach (string s in sa)
        //    //{
        //    var ems = SplitInner<EmoteInfo>(input);
        //    EmoteResult result = new EmoteResult(ems);
        //    if (result.Subscriber && list.All(t => !t.Name.Equals(result.Name)))
        //    {
        //        list.Add(result);
        //    }
        //    //}
        //    return list;
        //}

        public static List<Dictionary<FFZEmoteInfo, string>> ParseFFZEmotes(string input)
        {
            //if (input.Contains("lukix29"))
            //{
            //}
            input = input.Replace(" ", "");
            string[] sa = input.Split("},{");
            List<Dictionary<FFZEmoteInfo, string>> list = new List<Dictionary<FFZEmoteInfo, string>>();
            foreach (string s in sa)
            {
                var ems = SplitFFZInner<FFZEmoteInfo>(s, "\"", "{", "}");
                list.Add(ems);
            }
            return list;
        }

        public static Dictionary<FFZEmoteInfo, string> SplitFFZInner<T>(string input, params string[] remove)
        {
            var names = Enum.GetNames(typeof(FFZEmoteInfo));
            Dictionary<FFZEmoteInfo, string> sa = new Dictionary<FFZEmoteInfo, string>();
            foreach (var si in names)
            {
                var type = (FFZEmoteInfo)Enum.Parse(typeof(T), si);

                string endSplit = ",\"";
                if (si.Equals("urls"))
                {
                    endSplit = "},";
                }
                var name = "\"" + si + "\":";
                string value = input.GetBetween(name, endSplit);
                if (!string.IsNullOrEmpty(value))
                {
                    sa.Add(type, value.Trim('\"', '}', '{').ReplaceAll("", remove));
                }
            }
            return sa;
        }

        public static Dictionary<ApiInfo, string> SplitInner<T>(string input, string raw = "")
        {
            if (string.IsNullOrEmpty(raw))
            {
                raw = input;
            }
            var names = Enum.GetNames(typeof(T)).ToList();

            if (input.Contains("notifications")) names.Add("notifications");

            Dictionary<ApiInfo, string> sa = new Dictionary<ApiInfo, string>();
            foreach (var si in names)
            {
                var type = ApiInfo.delay;
                if (Enum.TryParse<ApiInfo>(si, out type))
                {
                    string endSplit = ",\"";
                    if (si.Equals("urls"))
                    {
                        endSplit = "},";
                    }
                    var name = "\"" + si + "\":";
                    string value = input.GetBetween(name, endSplit);
                    if (!string.IsNullOrEmpty(value))
                    {
                        sa.Add(type, value.Trim('\"', '}', '{'));
                    }
                }
                else
                {
                    sa.Add(ApiInfo.follow, bool.FalseString);
                    if (si.Equals("notifications"))
                    {
                        sa[ApiInfo.follow] = bool.TrueString;
                    }
                }
            }
            //if (sa.Count > 0)
            //{
            //    sa.Add(ApiInfo.follow, bool.FalseString);
            //    if (raw.Contains("notifications"))
            //    {
            //        sa[ApiInfo.follow] = bool.TrueString;
            //    }
            //    //sa.Add(ApiInfo.follow_created_at, bool.FalseString);
            //    //if (raw.Contains("notifications"))
            //    //{
            //    //    sa[ApiInfo.follow_created_at] = bool.TrueString;
            //    //}
            //}
            return sa;
        }

        public static Dictionary<PanelInfo, string> SplitPanelInner<T>(string input, params string[] remove)
        {
            var names = Enum.GetNames(typeof(PanelInfo));
            Dictionary<PanelInfo, string> sa = new Dictionary<PanelInfo, string>();
            foreach (var si in names)
            {
                var type = (PanelInfo)Enum.Parse(typeof(PanelInfo), si);

                string endSplit = ",\"";
                if (si.Equals("urls"))
                {
                    endSplit = "},";
                }
                var name = "\"" + si + "\":";
                string value = input.GetBetween(name, endSplit);
                if (!string.IsNullOrEmpty(value))
                {
                    sa.Add(type, value.Trim('\"', '}', '{').ReplaceAll("", remove));
                }
            }
            return sa;
        }
    }
}